//
// Created by baokh on 04/23/2019.
//

// THIS PROGRAM WAS WRITTEN BY KHUONG NGUYEN AND RAI PRAMOD

#include <iostream>
#include "menu.h"

//The menu
//feature should be handled by a separate function and not by main( )
int main()
{
    menu();
    return 0;
}