//
// Created by baokh on 04/23/2019.
//

/*****************************
 * RAI PRAMOD did this file
 *
 *
 *
 */
#include "readFromTwoFile.h"
#include "BSTree.hpp"
using namespace std;

void readFromFile1(ifstream& inFile,BSTree<GeneralData, string>& tree,vector<GeneralData>& myVector)
{
    string s;
    GeneralData temp;
    getline(inFile,s);
    while(getline(inFile,s))
    {
        int size;
        string sub;
        {
            size = s.find(',');
            sub = s.substr(0, size);
            s = s.substr(size + 1);
            temp.Year = sub;
            // find the comma and get YEAR from 0 to comma
            size = s.find(',');
            sub = s.substr(0, size);
            s = s.substr(size + 1);
            temp.Award = sub;
            // find the comma and get AWARD from first comma to second comma
            size = s.find(',');
            sub = s.substr(0, size);
            s = s.substr(size + 1);
            temp.Winner = sub;
            // find the comma and get WINNER from second comma to third comma
            size = s.find(',');
            sub = s.substr(0, size);
            temp.Name = sub;
            // find the comma and get NAME from third comma to four comma
            s = s.substr(size + 1);
            sub = s;
            temp.Film = sub;
            // FILM will be the last word

            tree.addNode(temp.Name, temp);
            // place the items in the BST
            myVector.push_back(temp);
            // place the items in the vector
        }
    }
    inFile.close();
}


// same idea like readfromFile1
void readFromFile2(ifstream& inFile, BSTree<GeneralData, string>& tree,vector<GeneralData>& myVector)
{
    inFile.open("pictures.csv");
    string s;
    GeneralData temp;
    getline(inFile,s);
    while(getline(inFile,s)){
        int size;
        string sub;
        {
            size = s.find(',');
            sub = s.substr(0, size);
            s = s.substr(size + 1);
            temp.Name = sub;

            size = s.find(',');
            sub = s.substr(0, size);
            s = s.substr(size + 1);
            temp.Year = sub;

            size = s.find(',');
            sub = s.substr(0, size);
            s = s.substr(size + 1);
            temp.nominations = atoi(sub.c_str()); // character to integer

            size = s.find(',');
            sub = s.substr(0, size);
            temp.rating = stof(sub.c_str());

            s = s.substr(size + 1);
            size = s.find(',');
            sub = s.substr(0, size);
            s = s.substr(size + 1);
            temp.duration = stof(sub.c_str());

            size = s.find(',');
            sub = s.substr(0, size);
            s = s.substr(size + 1);
            temp.genre1 = sub;

            size = s.find(',');
            sub = s.substr(0, size);
            s = s.substr(size + 1);
            temp.genre2 = sub;

            size = s.find(',');
            sub = s.substr(0, size);
            s = s.substr(size + 1);
            temp.release = sub;

            size = s.find(',');
            sub = s.substr(0, size);
            s = s.substr(size + 1);
            temp.metacritic = atoi(sub.c_str());

            size = s.find(',');
            sub = s.substr(0, size);
            s = s.substr(size + 1);
            temp.synopsis = sub;

            tree.addNode(temp.Name, temp);

            myVector.push_back(temp);
        }
    }
    inFile.close();
}