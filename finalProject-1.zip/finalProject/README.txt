*******************************************************
*  Name      :  Khuong Nguyen      Pramod Rai 
*  Student ID:  109120018          109039714
*  Class     :  CSC 2421           
*  Due Date  :  May 01, 2019
*******************************************************
                 Read Me
*******************************************************
*  Description of the program
*******************************************************
This is to create a database management program for
actor-actress.cvs, pictures.cvs and nomination.cvs

*******************************************************
*  ASSIGN WORK
*******************************************************
KHUONG NGUYEN: - menu.cpp
	       - menu.h
               - BSTree.hpp
               - partialSearchRecord function
	       - exactSearchRecord function
               - printOutFile function
               - printRecursive function
               - extra credit

RAI PRAMOD: - readFromTwoFile.cpp
            - readFromTwoFile.h
            - addNewRecord function
            - deleteRecord function
            - modifyRecord function
            - printOutVector function


*******************************************************
*  Source files
*******************************************************

Name:  main.cpp
   Main program.  This is the driver program
Name: readFromTwoFile.cpp
   Define and implement readFromFile which is read data 
   from actor-actress.csv,nomination.csv pictures.csv into 
   a tree
Name: menu.cpp
   Define menu and implement menu
Name: function.cpp
   Define and implement add, search, modify, delete, sort, printout functions
Name: BSTree.hpp
   Define and implement BSTree class which can modify a tree
*******************************************************
*  Status of program
*******************************************************
   The program runs successfully. 
   Extra Credit was added and run successfully. 
   The program was developed and tested on CLion g++.  It was 
   compiled, run, and tested on csegrid.ucdenver.pvt.