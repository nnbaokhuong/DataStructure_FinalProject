//
// Created by baokh on 04/23/2019.
//

/**************************
 * Khuong Nguyen did this file
 *
 *
 *
 */

#include "menu.h"
using namespace std;


// functions in this menu.cpp is pretty much identical to each other
// they are overall user interface
// and their main point is to call other functions to do the work.
void menu()
{
    BSTree<GeneralData, string>* treeActor = new BSTree<GeneralData, string>;
    BSTree<GeneralData, string>* treePicture = new BSTree<GeneralData, string>;
    BSTree<GeneralData, string>* treeNomination = new BSTree<GeneralData, string>;
    vector<GeneralData> myMovie;
    ifstream inFile;
    string fileName;
    int userInput;
    cout << "------------------------------------------------" << endl;
    cout << "Menu:" << endl;
    cout << "------------------------------------------------" << endl;
    cout << "Type 1 to read and access actor-actress database" << endl;
    cout << "Type 2 to read and access pictures database" << endl;
    cout << "Type 3 to read and access nominations database" << endl;
    cout << "Type 0 to exit program" << endl;

    cin >> userInput;
    while(userInput != 0)
    {
        switch(userInput)
        {
            case 1:{
                fileName = "actor-actress.csv";
                cout << "------------------------------" << endl;
                cout << "This is actor-actress database" << endl;
                cout << "------------------------------" << endl;
                inFile.open("actor-actress.csv");
                readFromFile1(inFile, *treeActor, myMovie);
                menuSub(inFile, *treeActor, myMovie,fileName);
                break;
            }
            case 2:{
                fileName = "pictures.csv";
                cout << "------------------------------" << endl;
                cout << "This is pictures database" << endl;
                cout << "------------------------------" << endl;
                readFromFile2(inFile, *treePicture, myMovie);
                menuSub(inFile, *treePicture, myMovie,fileName);
                break;
            }
            case 3:{
                fileName = "nominations.csv";
                cout << "------------------------------" << endl;
                cout << "This is nominations database" << endl;
                cout << "------------------------------" << endl;
                inFile.open("nominations.csv");
                readFromFile1(inFile, *treeNomination, myMovie);
                menuSub(inFile, *treeNomination, myMovie,fileName);
                break;
            }
            default:{
                cout << "***********************************************************************" << endl;
                cout << "Invalid input. Please follow the menu direction. Input 1 or 2 or 3 or 0" << endl;
                cout << "***********************************************************************" << endl;
                break;
            }
        }
        cout << "------------------------------------------------" << endl;
        cout << "Menu: " << endl;
        cout << "------------------------------------------------" << endl;
        cout << "Type 1 to read and access actor-actress database" << endl;
        cout << "Type 2 to read and access pictures database" << endl;
        cout << "Type 3 to read and access nominations database" << endl;
        cout << "Type 0 to exit program" << endl;
        cin >> userInput;
        myMovie.clear();
    }
    if(userInput == 0){ cout << "You are exiting. Bye Bye" << endl; }
}

void menuSub(ifstream& inFile, BSTree<GeneralData, string>& tree,vector<GeneralData>& myVector,string fileName)
{
    int userInput;
    Node<GeneralData, string>* myTreePtr = tree.Root();
    cout << "Type 1 to search a record in "<< fileName << endl;
    cout << "Type 2 to add a record in "<< fileName << endl;
    cout << "Type 3 to modify a record in "<< fileName << endl;
    cout << "Type 4 to delete a record in " << fileName << endl;
    cout << "Type 5 to print out updated of "<< fileName << endl;
    cout << "Type 6 to do sort in "<< fileName << endl;
    cout << "Type 0 to go back to main" << endl;
    cin >> userInput;
    while(userInput != 0)
    {
        switch(userInput)
        {
            case 1:{
                if(fileName == "actor-actress.csv" || fileName == "nominations.csv")
                    menuSearch1(tree, myTreePtr, fileName);

                else if(fileName == "pictures.csv")
                    menuSearch2(tree, myTreePtr, fileName);

                cout << "------------------------------" << endl;
                cout << "Successful search in " << fileName << endl;
                cout << "------------------------------" << endl;
                break;
            }
            case 2:{
                menuAdd(tree,fileName);
                cout << "------------------------------" << endl;
                cout << "Successful add in " << fileName << endl;
                cout << "------------------------------" << endl;
                break;
            }
            case 3:{
                menuModify(tree,fileName);
                cout << "------------------------------" << endl;
                cout << "Successful modify in " << fileName << endl;
                cout << "------------------------------" << endl;
                break;
            }
            case 4:{
                menuDelete(tree,fileName);
                cout << "------------------------------" << endl;
                cout << "Successful delete in " << fileName << endl;
                cout << "------------------------------" << endl;
                break;
            }
            case 5:{
                cout << "------------------------------" << endl;
                cout << "Print out to updatefile" << endl;
                cout << "------------------------------" << endl;

                printOutFile(tree,tree.Root(),fileName);
                break;
            }
            case 6:{
                cout << "------------------------------" << endl;
                cout <<"Welcome to sort..." << endl;
                cout << "------------------------------" << endl;
                if(fileName == "actor-actress.csv" || fileName == "nominations.csv")
                    menuSort1(tree, myVector);

                else if(fileName == "pictures.csv")
                    menuSort2(tree,myVector);

                break;
            }
            default:{
                cout << "***********************************************************************" << endl;
                cout << "Invalid input. Please follow the menu direction. Input 1 or 2 or 3 or 0" << endl;
                cout << "***********************************************************************" << endl;
                break;
            }
        }
        cout << "Type 1 to search a record in "<< fileName << endl;
        cout << "Type 2 to add a record in "<< fileName << endl;
        cout << "Type 3 to modify a record in "<< fileName << endl;
        cout << "Type 4 to delete a record in " << fileName << endl;
        cout << "Type 5 to print out updated of "<< fileName << endl;
        cout << "Type 6 to do sort in "<< fileName << endl;
        cout << "Type 0 to go back to main" << endl;
        cin >> userInput;
    }
}

void menuSearch1(BSTree<GeneralData, string>& tree,Node<GeneralData,string>* TreePtr,string fileName)
{
    int userInput;
    string field;
    cout << "------------------------------" << endl;
    cout << "Welcome to search in " << fileName << endl;
    cout << "------------------------------" << endl;
    cout << "Type 1 to search by year" << endl;
    cout << "Type 2 to search by name" << endl;
    cout << "Type 3 to search by film" << endl;
    cout << "Type 0 to back to main" << endl;
    cin >> userInput;
    while(userInput != 0)
    {
        switch(userInput)
        {
            case 1:{
                cout << "------------------------------" << endl;
                cout << "Search by year" << endl;
                cout << "------------------------------" << endl;
                cin.ignore();
                cout << "Please type in the YEAR you want to search: ";
                getline(cin,field);
                menuSubSearch(tree,TreePtr,"Year",field);
                break;
            }
            case 2:{
                cout << "------------------------------" << endl;
                cout << "Search by name" << endl;
                cout << "------------------------------" << endl;
                cin.ignore();
                cout << "Please type in the NAME you want to search: (Enter first name and last name For example: Emily Watson) ";
                getline(cin,field);
                menuSubSearch(tree,TreePtr,"Name",field);
                break;
            }
            case 3:{
                cout << "------------------------------" << endl;
                cout << "Search by film" << endl;
                cout << "------------------------------" << endl;
                cin.ignore();
                cout << "Please type in the FILM you want to search: (For example: The Last Command) ";
                getline(cin,field);
                menuSubSearch(tree,TreePtr,"Film",field);
                break;
            }
            default:{
                cout << "***********************************************************************" << endl;
                cout << "Invalid input. Please follow the menu direction. Input 1 or 2 or 3 or 0" << endl;
                cout << "***********************************************************************" << endl;
                break;
            }
        }
        cout << "Type 1 to search by year" << endl;
        cout << "Type 2 to search by name" << endl;
        cout << "Type 3 to search by film" << endl;
        cout << "Type 0 to back to main" << endl;
        cin >> userInput;
    }
}

void menuSearch2(BSTree<GeneralData, string>& tree,Node<GeneralData,string>* TreePtr,string fileName)
{
    int userInput;
    string field;
    cout << "------------------------------" << endl;
    cout << "Welcome to search in " << fileName << endl;
    cout << "------------------------------" << endl;
    cout << "Type 1 to search by year" << endl;
    cout << "Type 2 to search by film" << endl;
    cout << "Type 3 to search by nominations" << endl;
    cout << "Type 4 to search by genre" << endl;
    cout << "Type 5 to search by release" << endl;
    cout << "Type 0 to back to search" << endl;
    cin >> userInput;
    while(userInput != 0)
    {
        switch(userInput)
        {
            case 1:{
                cout << "------------------------------" << endl;
                cout << "Search by year" << endl;
                cout << "------------------------------" << endl;
                cin.ignore();
                cout <<"Please type in YEAR you want to search: ";
                getline(cin,field);
                menuSubSearch(tree,TreePtr,"Year",field);
                break;
            }
            case 2:{
                cout << "------------------------------" << endl;
                cout << "Search by film" << endl;
                cout << "------------------------------" << endl;
                cin.ignore();
                cout <<"Please type in NAME you want to search: (For example: 12 Years a Slave)";
                getline(cin,field);
                menuSubSearch(tree,TreePtr,"Name",field);
                break;
            }
            case 3:{
                cout << "------------------------------" << endl;
                cout << "Search by nominations" << endl;
                cout << "------------------------------" << endl;
                cin.ignore();
                cout <<"Please type in NOMINATION you want to search: (For example: 9)";
                getline(cin,field);
                menuSubSearch(tree,TreePtr,"nominations",field);
                break;
            }
            case 4:{
                cout << "------------------------------" << endl;
                cout << "Search by genre" << endl;
                cout << "------------------------------" << endl;
                cin.ignore();
                cout <<"Please type in GENRE you want to search: (For example: Drama)";
                getline(cin,field);
                menuSubSearch(tree,TreePtr,"genre",field);
                break;
            }
            case 5:{
                cout << "------------------------------" << endl;
                cout << "Search by release" << endl;
                cout << "------------------------------" << endl;
                cin.ignore();
                cout << "Please type in RELEASE you want to search: (For example: November,97)";
                getline(cin,field);
                menuSubSearch(tree,TreePtr,"release",field);
                break;
            }
            default:{
                cout << "***********************************************************************" << endl;
                cout << "Invalid input. Please follow the menu direction." << endl;
                cout << "***********************************************************************" << endl;
                break;
            }
        }
        cout << "Type 1 to search by year" << endl;
        cout << "Type 2 to search by film" << endl;
        cout << "Type 3 to search by nominations" << endl;
        cout << "Type 4 to search by genre" << endl;
        cout << "Type 5 to search by release" << endl;
        cout << "Type 0 to back to search" << endl;
        cin >> userInput;
    }
}

void menuAdd(BSTree<GeneralData, string>& tree, string fileName)
{
    int userInput;
    cout << "------------------------------" << endl;
    cout << "This is ADD menu" << endl;
    cout << "------------------------------" << endl;
    cout << "Type 1 to add new record in " << fileName << endl;
    cout << "Type 0 to go back to main" << endl;
    cin >> userInput;
    while(userInput != 0)
    {
        switch(userInput)
        {
            case 1:{
                cout << "------------------------------" << endl;
                cout << "Add new record in " << fileName << endl;
                cout << "------------------------------" << endl;
                addNewRecord(tree,fileName);
                break;
            }
            default:{
                cout << "***********************************************************************" << endl;
                cout << "Invalid input. Please follow the menu direction." << endl;
                cout << "***********************************************************************" << endl;
                break;
            }
        }
        cout << "Type 1 to add new record in " << fileName << endl;
        cout << "Type 0 to go back to main" << endl;
        cin >> userInput;
    }
}

void menuModify(BSTree<GeneralData, string>& tree,string& fileName)
{
    int userInput;
    cout << "------------------------------" << endl;
    cout << "This is MODIFY menu" << endl;
    cout << "------------------------------" << endl;
    cout << "Type 1 to modify a record in " << fileName << endl;
    cout << "Type 0 to go back to main" << endl;
    cin >> userInput;
    while(userInput != 0)
    {
        switch(userInput)
        {
            case 1:{
                cout << "------------------------------" << endl;
                cout << "Modify " << fileName << endl;
                cout << "------------------------------" << endl;
                modifyRecord(tree,fileName);
                break;
            }
            default:{
                cout << "***********************************************************************" << endl;
                cout << "Invalid input. Please follow the menu direction." << endl;
                cout << "***********************************************************************" << endl;
                break;
            }
        }
        cout << "Type 1 to modify a record in " << fileName << endl;
        cout << "Type 0 to go back to main" << endl;
        cin >> userInput;
    }
}

void menuDelete(BSTree<GeneralData,string>& tree, string fileName)
{
    int userInput;
    cout << "------------------------------" << endl;
    cout << "This is DELETE menu" << endl;
    cout << "------------------------------" << endl;
    cout << "Type 1 to delete a record in " << fileName << endl;
    cout << "Type 0 to go back to main" << endl;
    cin >> userInput;
    while(userInput != 0)
    {
        switch(userInput)
        {
            case 1:{
                deleteRecord(tree);
                cout << "------------------------------" << endl;
                cout << "Successful delete in " << fileName << endl;
                cout << "------------------------------" << endl;
                break;
            }
            default:{
                cout << "***********************************************************************" << endl;
                cout << "Invalid input. Please follow the menu direction." << endl;
                cout << "***********************************************************************" << endl;
                break;
            }
        }
        cout << "Type 1 to delete a record in " << fileName << endl;
        cout << "Type 0 to go back to main" << endl;
        cin >> userInput;
    }
}

void menuSubSearch(BSTree<GeneralData, string>& tree,Node<GeneralData, string>* treePtr,string searchField,string field)
{
    int userInput;
    cout << "------------------------------" << endl;
    cout << "EXACT OR PARTIAL SEARCH"  << endl;
    cout << "------------------------------" << endl;
    cout << "Type 1 to do exact search" << endl;
    cout << "Type 2 to do partial search" << endl;
    cout << "Type 0 to go back to search menu" << endl;
    cin >> userInput;
    while(userInput != 0)
    {
        switch(userInput)
        {
            case 1:{
                exactSearchRecord(tree,treePtr,searchField,field);
                break;
            }
            case 2:{
                partialSearchRecord(tree,treePtr,searchField,field);
                break;
            }
            default:{
                cout << "***********************************************************************" << endl;
                cout << "Invalid input. Please follow the menu direction. Input 1 or 2 or 3 or 0" << endl;
                cout << "***********************************************************************" << endl;
                break;
            }
        }
        cout << "------------------------------" << endl;
        cout << "EXACT OR PARTIAL SEARCH"  << endl;
        cout << "------------------------------" << endl;
        cout << "Type 1 to do exact search" << endl;
        cout << "Type 2 to do partial search" << endl;
        cout << "Type 0 to go back to search menu" << endl;
        cin >> userInput;
    }
}

void menuSort1(BSTree<GeneralData,string>& tree,vector<GeneralData>& myVector)
{
    int userInput;
    cout << "------------------------------" << endl;
    cout << "This is SORT menu" << endl;
    cout << "------------------------------" << endl;
    cout << "Type 1 to sort by year" << endl;
    cout << "Type 2 to sort by film" << endl;
    cout << "Type 3 to sort by name" << endl;
    cout << "Type 0 to back to main" << endl;
    cin >> userInput;
    while(userInput != 0)
    {
        switch(userInput)
        {
            case 1:{
                sortRecursive(myVector,0, myVector.size() - 1,"Year");
                printOutVector(myVector);
                break;
            }
            case 2:{
                sortRecursive(myVector,0, myVector.size() - 1,"Film");
                printOutVector(myVector);
                break;
            }
            case 3:{
                tree.printInorder();
            }
            default:{
                cout << "***********************************************************************" << endl;
                cout << "Invalid input. Please follow the menu direction." << endl;
                cout << "***********************************************************************" << endl;
                break;
            }
        }
        cout << "Type 1 to sort by year" << endl;
        cout << "Type 2 to sort by film" << endl;
        cout << "Type 3 to sort by name" << endl;
        cout << "Type 0 to back to main" << endl;
        cin >> userInput;
    }
}

void menuSort2(BSTree<GeneralData,string>& tree,vector<GeneralData>& myVector)
{
    int userInput;
    cout << "------------------------------" << endl;
    cout << "This is SORT menu" << endl;
    cout << "------------------------------" << endl;
    cout << "Type 1 to sort by year" << endl;
    cout << "Type 2 to sort by film" << endl;
    cout << "Type 3 to sort by nominations" << endl;
    cout << "Type 4 to sort by rating" << endl;
    cout << "Type 5 to sort by genre1" << endl;
    cout << "Type 0 to back to main" << endl;
    cin >> userInput;
    while(userInput != 0)
    {
        switch(userInput)
        {
            case 1:{
                sortRecursive(myVector,0, myVector.size() - 1,"Year");
                printOutVector(myVector);
                break;
            }
            case 2:{
                tree.printInorder();
                break;
            }
            case 3:{
                sortRecursive(myVector,0, myVector.size() - 1,"nominations");
                printOutVector(myVector);
                break;
            }
            case 4:{
                sortRecursive(myVector,0, myVector.size() - 1,"rating");
                printOutVector(myVector);
                break;
            }
            case 5:{
                sortRecursive(myVector,0, myVector.size() - 1,"genre1");
                printOutVector(myVector);
                break;
            }
            default:{
                cout << "***********************************************************************" << endl;
                cout << "Invalid input. Please follow the menu direction." << endl;
                cout << "***********************************************************************" << endl;
                break;
            }
        }
        cout << "Type 1 to sort by year" << endl;
        cout << "Type 2 to sort by film" << endl;
        cout << "Type 3 to sort by nominations" << endl;
        cout << "Type 4 to sort by rating" << endl;
        cout << "Type 5 to sort by genre1" << endl;
        cout << "Type 0 to back to main" << endl;
        cin >> userInput;
    }
}
