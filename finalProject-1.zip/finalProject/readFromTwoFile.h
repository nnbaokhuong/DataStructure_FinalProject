//
// Created by baokh on 04/23/2019.
//

/*****************************
 * RAI PRAMOD did this file
 *
 *
 *
 */

#ifndef DATABASE_READFROMFILE1_H
#define DATABASE_READFROMFILE1_H
#include <fstream>
#include <iostream>
#include <vector>
#include "BSTree.h"
using namespace std;

class readFromTwoFile {};

//R1/R2: You are to read in information from two files.
void readFromFile1(ifstream& inFile, BSTree<GeneralData, string>& tree,vector<GeneralData>& myVector);
// Return: read from actor-actress.cvs or read nomination.cvs
void readFromFile2(ifstream& inFile, BSTree<GeneralData, string>& picTree,vector<GeneralData>& myVector);
// Return: read from pictures.cvs


#endif //DATATBASE_READFROMTWOFILE_H
