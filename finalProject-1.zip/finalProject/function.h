//
// Created by baokh on 04/23/2019.
//

#ifndef DATATBASE_FUNCTION_H
#define DATATBASE_FUNCTION_H
#include <iostream>
#include <vector>
#include <cstdlib>
#include <fstream>
#include "BSTree.hpp"
using namespace std;


void addNewRecord(BSTree<GeneralData, string>& tree,string& fileName);
//Precondition: Record is not yet exist in database
//              Add new record into database
//Postcondition: Add a new record to database
/*****************************
 * RAI PRAMOD did this file
 *
 *
 *
 *
 *
 */

void deleteRecord(BSTree<GeneralData,string>& tree);
//Precondition: Record is exist in database
//              Delete existing record
//Postcondition: Delete a record in database
/*****************************
 * RAI PRAMOD did this file
 *
 *
 *
 *
 *
 */

void modifyRecord(BSTree<GeneralData,string>& tree, string& fileName);
//Precondition: Record is exist in database
//              Modify existing record
//Postcondition: Modify a record in database
/*****************************
 * RAI PRAMOD did this file
 *
 *
 *
 *
 *
 */

void printOutVector(vector<GeneralData>& myVector);
//Precondition: myVector contain every single record in database
//Postcondition: Output every record to console
/*****************************
 * RAI PRAMOD did this file
 *
 *
 *
 *
 *
 */

void partialSearchRecord(BSTree<GeneralData, string>& tree,Node<GeneralData,string> * TreePtr,string& searchField,string& field);
//Precondition: Record is exist in database
//              Partial search every record in database
//Postcondition: Output records that match
/*****************************
 * Khuong Nguyen did this file
 *
 *
 *
 *
 *
 */

void exactSearchRecord(BSTree<GeneralData, string>& tree,Node<GeneralData,string> * TreePtr,string &searchField,string& field);
//Postcondition: Exact search every record in database
//               Output records that match
/*****************************
 * Khuong Nguyen did this file
 *
 *
 *
 *
 *
 */

void printOutFile(BSTree<GeneralData, string>& tree,Node<GeneralData,string>* node, string fileName);
//Precondititon: Filename is exist
//Postcondition: Output every record in database to new file
/*****************************
 * Khuong Nguyen did this file
 *
 *
 *
 *
 *
 */

void printRecursive(BSTree<GeneralData, string>& tree,Node<GeneralData,string>* node,ofstream& updateFile);
// Postcondition: print out the tree recursively to updateFile
/*****************************
 * Khuong Nguyen did this file
 *
 *
 *
 *
 *
 */



void sortRecursive(vector<GeneralData>& myVector,int l,int r,string sortField);
//This function is to use with mergeSort function
//Merge sort. Credit by https://en.wikipedia.org/wiki/Merge_sort
void mergeSort(vector<GeneralData>& myVector,int l ,int m,int r, std::string mergeField);
//Merge sort. Credit by https://en.wikipedia.org/wiki/Merge_sort

/*********************************
 *  * Documentation from online source
 *
 *
 *
 *
 */



#endif //DATATBASE_FUNCTION_H
