//
// Created by baokh on 04/23/2019.
//

/**************************
 * Khuong Nguyen did this file
 *
 *
 *
 */

#ifndef DATATBASE_MENU_H
#define DATATBASE_MENU_H
#include <iostream>
#include <vector>
#include <fstream>
#include "readFromTwoFile.h"
#include "function.h"
using namespace std;
class menu {};


void menu();
//Return: main menu
void menuSub(ifstream& inFile, BSTree<GeneralData, string>& tree,vector<GeneralData>& myVector,string fileName);
//Return: submenu contain add, search, delete, modify menu
void menuSearch1(BSTree<GeneralData, string>& tree,Node<GeneralData,string>* TreePtr,string fileName);
//Return: menu to search for actor-actress.csv and nominations.csv
void menuSearch2(BSTree<GeneralData, string>& tree,Node<GeneralData,string>* TreePtr,string fileName);
//Return: menu to search for pictures.csv
void menuAdd(BSTree<GeneralData, string>& tree, string fileName);
//Return: menu to add new record
void menuModify(BSTree<GeneralData, string>& tree, string&fileName);
//Return: menu to modify existing record
void menuDelete(BSTree<GeneralData,string>& tree, string fileName);
//Return: menu to delete existing record
void menuSubSearch(BSTree<GeneralData, string>& tree,Node<GeneralData, string>* treePtr,string searchField, string field);
//Return: submenu to search exact and partial
void menuSort1(BSTree<GeneralData,string>& tree,vector<GeneralData>& myVector);
//Return: menu to sort for actor-actress.csv and nominations.csv
void menuSort2(BSTree<GeneralData,string>& tree,vector<GeneralData>& myVector);
//Return: menu to sort for pictures.csv


#endif //DATATBASE_MENU_H
