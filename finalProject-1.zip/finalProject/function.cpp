//
// Created by baokh on 04/23/2019.
//

#include "function.h"
#include <string>
using namespace std;

void addNewRecord(BSTree<GeneralData,string>& tree,string& fileName)
{
    GeneralData newRecord;
    if(fileName != "pictures.csv")
    {
        cout << "------------------------------" << endl;
        cout << "Please input your new record as the following" << endl;
        cout << "Year,Award,Winner,Name,Film" << endl;
        cout << "------------------------------" << endl;
        // Input YEAR
        cout << "Year: " << endl;
        cin >> newRecord.Year;
        // Input AWARD
        cout << "Award: " << endl;
        cin.ignore();
        getline(cin, newRecord.Award);
        // Input WINNER
        cout << "Winner: " << endl;
        cin >> newRecord.Winner;
        // Input NAME
        cout << "Name: " << endl;
        cin.ignore();
        getline(cin, newRecord.Name);
        // Input FILM
        cout << "Film: " << endl;
        getline(cin, newRecord.Film);

        // add new record to BST
        tree.addNode(newRecord.Name, newRecord);
    }
    else {
        cout << "------------------------------" << endl;
        cout << "Please input your new record as the following" << endl;
        cout << "name,year,nominations,rating,duration,genre1,genre2,release,metacritic,synopsis" << endl;
        cout << "------------------------------" << endl;
        // Input NAME
        cout << "Name: (For Example: Magnolia)" << endl;
        cin.ignore();
        getline(cin,newRecord.Name);
        // Input YEAR
        cout << "Year: (For Example: 2016)" << endl;
        getline(cin, newRecord.Year);
        // Input NOMINATION
        cout << "Nominations: (for example: 1)" << endl;
        cin >> newRecord.nominations;
        // Input RATING
        cout << "Rating: (For Example: 1.5)" << endl;
        cin >>newRecord.rating;
        // Input DURATION
        cout << "Duration: (For Example: 90.5)" << endl;
        cin >> newRecord.duration;
        // Input GENRE1
        cout << "Genre1: (For Example: Drama)" << endl;
        cin.ignore();
        getline(cin, newRecord.genre1);
        // Input GENRE2
        cout << "Genre2: (For example: Comedy)" << endl;
        getline(cin,newRecord.genre2);
        // Input RELEASE
        cout << "Release: " << endl;
        getline(cin,newRecord.release);
        // Input METACRITIC
        cout << "Metacritic: " << endl;
        cin >> newRecord.metacritic;
        // Input SYNOPSIS
        cout << "synopsis:" << endl;
        cin.ignore();
        getline(cin,newRecord.synopsis);
        // add new record to BST
        tree.addNode(newRecord.Name, newRecord);
    }
    cout <<"Successful added record to updateFile " << endl;
    tree.print(cout,newRecord);
    cout << endl;
}


void deleteRecord(BSTree<GeneralData,string>& tree)
{
    // Travel the tree to find match record that user want to delete
    cout << "Please input name of actor you want to delete: (Enter first name and last name For example: Emily Watson)" << endl;
    GeneralData record;
    cin.ignore();
    getline(cin,record.Name);

    if(tree.findNode(record.Name) != nullptr) { tree.deleteNode(record.Name); }
    else { cout <<"Record is already deleted or not in database" << endl; }
}

void modifyRecord(BSTree<GeneralData,string>& tree,string& fileName)
{
    //Travel the tree and find match record and modify it
    GeneralData changeRecord;
    Node<GeneralData,string>* treePtr;
    string field;
    cout << "Please input name of record you want to modify. (Enter first name and last name For example: Emily Watson) " << endl;
    cin.ignore();
    getline(cin, field);

    treePtr = tree.findNode(field);
    if(treePtr == nullptr) { cout << "Record is not in database. You cannot modify it. " << endl; }
    else{
        if(fileName == "pictures.csv")
        {
            int menu;
            do {
                cout << "Type 0 to change name" << endl;
                cout << "Type 1 to change year" << endl;
                cout << "Type 2 to change nominations" << endl;
                cout << "Type 3 to change rating" << endl;
                cout << "Type 4 to change duration" << endl;
                cout << "Type 5 to change genre1" << endl;
                cout << "Type 6 to change genre2" << endl;
                cout << "Type -1 if you want to exit" << endl;
                cin >> menu;
                changeRecord = treePtr->Data();
                switch(menu)
                {
                    case 0: {
                        cout << "Type new name " << endl;
                        cin.ignore();
                        getline(cin,changeRecord.Name);
                        break;
                    }
                    case 1:{
                        cout <<"Type new year " << endl;
                        cin >> changeRecord.Year;
                        break;
                    }
                    case 2:{
                        cout << "Type new nomination:(must be an integer number) " << endl;
                        cin >> changeRecord.nominations;
                        break;
                    }
                    case 3:{
                        cout << "Type new rating:(must be a real number) " << endl;
                        cin >> changeRecord.rating;
                        break;
                    }
                    case 4:{
                        cout << "Type new duration:(must be a real number) " << endl;
                        cin >> changeRecord.duration;
                        break;
                    }
                    case 5:{
                        cout << "Type new genre1: " << endl;
                        cin >> changeRecord.genre1;
                        break;
                    }
                    case 6:{
                        cout << "Type new genre2: " << endl;
                        cin >> changeRecord.genre2;
                        break;
                    }
                    default: {
                        break;
                    }
                }

                treePtr->setData(changeRecord);
                cout << "Your modified record is: "<< endl;
                tree.print(cout, changeRecord);
            } while(menu != - 1);
        }
        else if(fileName == "actor-actress.csv" || fileName == "nominations.csv")
        {
            int menu;
            do{
                cout << "Type 0 to change year" << endl;
                cout << "Type 1 to change award" << endl;
                cout << "Type 2 to change winner" << endl;
                cout << "Type 3 to change name" << endl;
                cout << "Type 4 to change film" << endl;
                cout << "Type -1 if you want to exit" << endl;
                cin >> menu;
                changeRecord = treePtr->Data();
                switch(menu)
                {
                    case 0:{
                        cout <<"Type new year " << endl;
                        cin >> changeRecord.Year;
                        break;
                    }
                    case 1:{
                        cout <<"Type new award " << endl;
                        cin.ignore();
                        getline(cin,changeRecord.Award);
                        break;
                    }
                    case 2:{
                        cout << "Input winner. 0 or 1" << endl;
                        cin >> changeRecord.Winner;
                        break;
                    }
                    case 3:{
                        cout <<"Input Name. For example: Birdman" << endl;
                        cin.ignore();
                        getline(cin,changeRecord.Name);
                        break;
                    }
                    case 4:{
                        cout <<"Input film" << endl;
                        cin.ignore();
                        getline(cin,changeRecord.Film);
                        break;
                    }
                    default:{
                        break;
                    }
                }
                treePtr->setData(changeRecord);
                cout <<"Your modified record is"<< endl;
                tree.print(cout, changeRecord);
            }while(menu != - 1);
        }
        else{
            cout <<"Sorry. File is not exist" << endl;
        }
    }
}

void printOutVector(vector<GeneralData>& myVector)
{
    for(auto i : myVector)
    {
        if(i.synopsis == "")
        {
            cout << i.Year << "," << i.Award << "," << i.Winner
                 << "," << i.Name << "," << i.Film << endl;
        }
        else {
            cout << i.Name << "," << i.Year << "," << i.nominations
                 <<"," << i.rating << "," << i.duration << ","
                 << i.genre1 << "," << i.genre2 << "," << i.release
                 << "," << i.metacritic << "," << i.synopsis << endl;
        }
    }
}

void partialSearchRecord(BSTree<GeneralData, string>& tree,Node<GeneralData,string> * TreePtr,string &searchField,string& field)
{
    // travel entire tree using recursive left and right
    // check if user input is match then print out
    if(TreePtr == nullptr)
    {
        return;
    }
    // recursion
    partialSearchRecord(tree,TreePtr->Left(),searchField,field);
    if(searchField == "Name")
    {
        if (TreePtr->Data().Name.find(field) != string::npos)
            tree.print(cout, TreePtr->Data());

    }
    else if(searchField == "Film")
    {
        if (TreePtr->Data().Film.find(field) != string::npos)
            tree.print(cout, TreePtr->Data());
    }
    else if(searchField == "Year")
    {
        if (TreePtr->Data().Year.find(field) != string::npos)
            tree.print(cout, TreePtr->Data());
    }
    else if(searchField == "nominations")
    {
        if (to_string(TreePtr->Data().nominations).find(field) != string::npos)
            tree.print(cout, TreePtr->Data());
    }
    else if(searchField == "rating")
    {
        if (to_string(TreePtr->Data().rating).find(field) != string::npos)
            tree.print(cout, TreePtr->Data());
    }
    else if(searchField == "genre")
    {
        if (TreePtr->Data().genre1.find(field) != string::npos || TreePtr->Data().genre2.find(field) != string::npos)
            tree.print(cout, TreePtr->Data());
    }
    else if(searchField == "release")
    {
        if (TreePtr->Data().release.find(field) != string::npos)
            tree.print(cout, TreePtr->Data());
    }
    partialSearchRecord(tree,TreePtr->Right(),searchField,field);
}


void exactSearchRecord(BSTree<GeneralData, string>& tree,Node<GeneralData,string> * TreePtr,string &searchField,string& field)
{
    // travel entire tree using recursive left and right
    // check if user input is match then print out
    if(TreePtr == nullptr){
        return;
    }
    exactSearchRecord(tree,TreePtr->Left(),searchField,field);
    if(searchField == "Name")
    {
        if (TreePtr->Data().Name == field)
            tree.print(cout, TreePtr->Data());
    }
    else if(searchField == "Film")
    {
        if (TreePtr->Data().Film == field)
            tree.print(cout, TreePtr->Data());
    }
    else if(searchField == "Year")
    {
        if (TreePtr->Data().Year == field)
            tree.print(cout, TreePtr->Data());
    }
    else if(searchField == "nominations")
    {
        if (to_string(TreePtr->Data().nominations) == (field))
            tree.print(cout, TreePtr->Data());
    }
    else if(searchField == "rating")
    {
        if (to_string(TreePtr->Data().rating) == (field))
            tree.print(cout, TreePtr->Data());
    }
    else if(searchField == "genre")
    {
        if (TreePtr->Data().genre1 == field || TreePtr->Data().genre2 == field)
            tree.print(cout, TreePtr->Data());
    }
    else if(searchField == "release")
    {
        if (TreePtr->Data().release == field)
            tree.print(cout, TreePtr->Data());
    }
    exactSearchRecord(tree,TreePtr->Right(),searchField,field);
}


void printOutFile(BSTree<GeneralData,string>& tree,Node<GeneralData,string>* node,string fileName)
{
    if(node == nullptr)
        return;
    ofstream updateFile;
    if(fileName == "actor-actress.csv" || fileName == "nominations.csv")
    {
        string name;
        name = "updated" + fileName;
        updateFile.open(name);
    }
    else if (fileName == "pictures.csv")
    {
        string name;
        name = "updated" + fileName;
        updateFile.open(name);
    }
    printRecursive(tree,node,updateFile);
    cout << "Successfully write out to File" << endl;
    updateFile.close();
}


void printRecursive(BSTree<GeneralData,string>& tree,Node<GeneralData,string>* node,ofstream& updateFile)
{
    if (node == nullptr)
        return;
    printRecursive(tree,node->Left(),updateFile);
    tree.print(updateFile,node->Data());
    printRecursive(tree,node->Right(),updateFile);
}



void sortRecursive(vector<GeneralData>& myVector,int l,int r,string sortField)
{
    //Merge sort
    if (l < r)
    {
        int m = l + (r - l) / 2;
        sortRecursive(myVector, l, m, sortField);
        sortRecursive(myVector, m + 1, r, sortField);
        mergeSort(myVector,l,m,r, sortField);
    }
}


void mergeSort(vector<GeneralData>& myVector,int l,int m,int r,string mergeField)
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 =  r - m;

    /* create temp vector*/
    vector<GeneralData> L, R;

    /* Copy data to temp arrays L[] and R[] */
    for (i = 0; i < n1; i++)
        L.push_back(myVector[l + i]);
    for (j = 0; j < n2; j++)
        R.push_back(myVector[m + 1+ j]);

    /* Merge the temp arrays back into vector*/
    i = 0; // Initial index of first subarray
    j = 0; // Initial index of second subarray
    k = l; // Initial index of merged subarray
    if(mergeField == "Film")
    {
        while (i < n1 && j < n2)
        {
            if (L[i].Film <= R[j].Film)
            {
                myVector[k] = L[i];
                i++;
            }
            else
            {
                myVector[k] = R[j];
                j++;
            }
            k++;
        }
    }
    else if(mergeField == "Year")
    {
        while (i < n1 && j < n2)
        {
            if (L[i].Year<= R[j].Year)
            {
                myVector[k] = L[i];
                i++;
            }
            else
            {
                myVector[k] = R[j];
                j++;
            }
            k++;
        }
    }
    else if (mergeField == "rating")
    {
        while (i < n1 && j < n2)
        {
            if (L[i].rating<= R[j].rating)
            {
                myVector[k] = L[i];
                i++;
            }
            else
            {
                myVector[k] = R[j];
                j++;
            }
            k++;
        }
    }
    else if (mergeField == "nominations")
    {
        while (i < n1 && j < n2)
        {
            if (L[i].nominations<= R[j].nominations)
            {
                myVector[k] = L[i];
                i++;
            }
            else
            {
                myVector[k] = R[j];
                j++;
            }
            k++;
        }
    }
    else if (mergeField == "genre1")
    {
        while (i < n1 && j < n2)
        {
            if (L[i].rating<= R[j].rating)
            {
                myVector[k] = L[i];
                i++;
            }
            else
            {
                myVector[k] = R[j];
                j++;
            }
            k++;
        }
    }
    /* Copy the remaining elements of L[], if there
       are any */
    while (i < n1)
    {
        myVector[k] = L[i];
        i++;
        k++;
    }
    /* Copy the remaining elements of R[], if there
       are any */
    while (j < n2)
    {
        myVector[k] = R[j];
        j++;
        k++;
    }
    L.clear();
    R.clear();
}


